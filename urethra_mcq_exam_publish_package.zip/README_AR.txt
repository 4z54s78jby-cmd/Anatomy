Urethra Anatomy – Interactive MCQ Exam

To publish this as a permanent public website using GitHub Pages:

1. Sign in to https://github.com/ (create a free account if needed).
2. Create a new public repository, for example: urethra-mcq-exam
3. Upload the file urethra_interactive_mcq_exam.html.
4. Rename it to index.html in the repository.
5. Open Settings → Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Select branch main and folder /(root), then Save.
8. Wait for GitHub Pages to publish. The permanent URL will appear in Settings → Pages and look like:
   https://YOUR-USERNAME.github.io/urethra-mcq-exam/

Note: A public hosting account is required to publish a permanent public URL. This package is ready to upload; it has not been published yet.
